AGENCE IMMOBILIER ANTSIRABE - V4
index.html = site public
admin.html = tableau de bord prototype

DEMO ADMIN: 1234

Important:
Cette V4 utilise localStorage du navigateur. Elle sert à démontrer le fonctionnement.
Pour un vrai site public, il faut un hébergement + base de données + authentification serveur afin que les annonces ajoutées par l'agence soient visibles à tous les visiteurs.
